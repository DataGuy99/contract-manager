# Contractor Manager

Single-file web app for running an electrical contracting business: projects with
budgets/phases/P&L, crew hour logging, materials with spreadsheet import, change
orders, expenses (incl. gas/mileage), invoices, activity logs, notes with slash
commands, weekly crew schedule, project map, plan takeoff, and print-ready
panel schedules.

## Deploy

`index.html` is the entire app — drop it on Netlify (or any static host).
CDN dependencies (Leaflet for the map, SheetJS for spreadsheet import/export)
load at runtime; the app degrades gracefully offline.

## Data

All data lives in the browser (IndexedDB) behind a small storage adapter
(`Store` in `src/01-core-state-controls.js.html`) designed to be swapped for a
server backend later. Backup/restore via Export/Import JSON in the ⚙ settings
menu. Takeoff plan images are stored inside the data, so they survive reloads
and travel with backups.

## Source

The app is built by concatenating the files in `src/` (they sort in build
order). Edit there, then run:

```sh
sh src/build.sh   # regenerates ./index.html
```

Editing `index.html` directly also works — it IS the app — just keep `src/`
in sync (or re-split) if you do.

- `src/00-head-css.html` — head, theme variables, all CSS
- `src/00b-body-markup.html` — header/nav/tab shells
- `src/01-core-state-controls.js.html` — state, IndexedDB store, custom dropdown/datepicker/number/toggle/modal components
- `src/02-nav-settings-team.js.html` — tab routing, theme & settings popup, team/pay/availability popup
- `src/03-dashboard-project.js.html` — dashboard KPIs/table, address autocomplete, project modal top, budget & phases, invoices
- `src/04-project-sections-quickadd.js.html` — people/hour logs, materials + xlsx import, change orders, expenses (searchable categories, mileage), files, activity log, quick log, cost summary, global Quick Add
- `src/05-myplate-materials.js.html` — My Plate notes with `//` command menu, Materials tab
- `src/06-schedule-map.js.html` — drag-drop weekly schedule, Leaflet map
- `src/07-takeoff.js.html` — plan canvas: scale/area/device/conduit/measure, push estimate
- `src/08-panels-init.js.html` — panel schedule presets/editor/print, app init

`templates/material_import_template.xlsx` — the spreadsheet users fill to bulk-import materials.

See `docs/PROGRESS.md` for the rebuild log, feature status, and roadmap.
