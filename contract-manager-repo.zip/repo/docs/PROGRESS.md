# Progress & Notes — 2026-07-02 rebuild

Source of the previous build was lost; this is a ground-up recreation from
screenshots of the running app plus the detailed Panel_Schedule.xlsx, with the
outstanding fix list applied. Storage history: Supabase → local IndexedDB
(current) → local server (planned). The storage adapter is isolated so the
server swap doesn't touch UI code.

## Recreated from screenshots
- Dashboard: Open Projects / Open Invoices / Paid Invoices / Total P&L cards,
  date-range filtered project table (status dot, client, type, cost, revenue, P&L)
- Project modal: address w/ autocomplete (Nominatim), client/phone(call)/email,
  Fixed vs T&M, budget & phases w/ % allocation + target vs actual + released
  tracking, people w/ per-date hour logs, materials, change orders, expenses,
  files, activity log, quick log/note, cost summary, template/delete
- T&M projects: invoices w/ paid/open, billed materials at markup
- Team popup: members, rates (hourly/salary), pay-period totals
- Theme popup: primary/secondary colors, markup %, pay period
- Schedule: week grid, per-day person chips, All Day/AM/PM
- Map: Leaflet dark tiles, F/$ pins, open/done coloring
- Takeoff: plan upload, Select/Scale/Area/Device/Conduit/Measure/Undo/Fit,
  summary (devices, sqft, conduit, device cost, billed, dev/sqft), Push Est.
- My Plate: note list, search, recurring

## Fix list — all shipped this build
1. Invoice rename after creation ✔
2. Material import from template spreadsheet ✔ (+ template generator in-app and in /templates)
3. Importable template spreadsheet created ✔
4. Per-line-item perimeter/edge color to separate items ✔
5. Expense search field that adds unknown items as new categories ✔
6. Edit name/desc of expenses and added items generally ✔
7. Gas/mileage: desc + miles, admin $/mile rate (default 0.75) ✔
8. Granular statuses beyond open/done (custom, colored, user-defined) ✔
9. All default dropdowns/date inputs replaced with custom controls ✔
10. Hours-for-one-person-applies-to-all bug fixed (logs keyed per member) ✔
11. Schedule: larger, drag person→day, AM/PM/custom from:to, per-person
    availability restrictions in Team popup ✔
12. Takeoff prints persisted in app data (fixes plans not appearing after reload;
    cross-user visibility still needs the server) ✔
13. Quick note allows person(s) + task + time taken ✔
14. Quick Add records timestamps; entries sort chronologically in activity log ✔
15. Activity log asc/desc toggle, persists globally across projects, plus
    date-range filter ✔
16. Theme variety: white, milk, eggshell, beige, taupe, gray, dark, black ✔
17. My Plate `//` slash menu: log hours, material, expense, todo list, bullets,
    link to project, material list, share (stub) — entries populate the linked
    project and its activity log ✔

## New: Panels tab (from Panel_Schedule.xlsx)
- Branding block (logo upload, company, slogan, phone • email • website) from settings
- Presets: Square D QO/Homeline/NQ/NF/I-Line, Eaton BR/CH/PRL2, Siemens, GE,
  120-ckt panelboard, custom — auto-fill brand/series/main/bus/voltage/phase
- Panel/job details: ID, location, fed from, date, mounting, AIC
- Circuits count sets rows (≤120); two-column CKT grid
- 1/2/3-pole breakers: click P cell to cycle; multi-pole spans consecutive
  slots on the same side (rowspan) w/ shared description
- Phase column auto-balances: A/B for 1Ø, A/B/C for 3Ø
- Notes block; Print/PDF renders a clean white sheet

## Known limitations / next up
- Share / Sign Out are stubs until the local-server backend lands
- Data is per-browser (IndexedDB); Export/Import JSON is the bridge
- Nominatim autocomplete is rate-limited (1 req/sec) — fine for manual entry
- Takeoff: no polygon-edit after placement (delete & redraw); conduit priced at $0 on push (edit in materials)
- Schedule: no multi-week view yet; drag between days = remove + re-drop
- Roadmap: server sync + auth, real sharing, template projects, full UI redesign pass
