#!/bin/sh
# Rebuild ../index.html from the split source files (they concatenate in name order).
cd "$(dirname "$0")"
cat 00-head-css.html 00b-body-markup.html 0[1-8]-*.js.html 09-tail.html > ../index.html
echo "built ../index.html"
